# Annalista
a program that  streams tweets related to COVID-19 vaccine and creates sentiment analysis, topic modeling and feature extraction
